#!/usr/bin/env python
# coding: utf-8

__title__ = '{{ name }}'
__version__ = '0.1'
__author__ = '{{ username }}'
__license__ = '{{ license }}'
__copyright__ = 'Copyright {{ year }} {{ username }}'