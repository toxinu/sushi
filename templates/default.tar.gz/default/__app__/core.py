#!/usr/bin/env python
# coding: utf-8
import os

from {{ name }}.logger import logger