#!/usr/bin/env python
# coding: utf-8
import os

from sushi.core import logger

def run(dst):
	logger.info('    -> Run {{ name }}')